module.exports = {
	'secret': 'secretTesting'
};
