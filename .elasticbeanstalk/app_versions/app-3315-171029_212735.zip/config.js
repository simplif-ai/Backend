module.exports = {
	'secret': 'secretTesting'
};
